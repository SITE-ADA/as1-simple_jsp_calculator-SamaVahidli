package ada.wm2;

public class Calculator {
  private int p1, p2;
  private String op;
  private double res;

  public Calculator(int p1, int p2, String op) {
    this.p1 = p1;
    this.p2 = p2;
    this.op = op;
  }

  public double run() {
    switch (this.op) {
      case "add":
        res = this.p1 + this.p2;
        break;
      
      case "sub":
        res = this.p1 - this.p2;
        break;

      case "mul":
        res = this.p1 * this.p2;
        break;

      case "div":
        res = (this.p1 * 1.0) / this.p2;
        break;

      default:
        throw new Error("Invalid OP code");
    }

    return this.res;
  }
}